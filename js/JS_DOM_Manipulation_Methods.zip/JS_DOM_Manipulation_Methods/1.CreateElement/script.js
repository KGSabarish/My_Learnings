// // Create a new div element
// var newDiv = document.createElement('div');

// // Set attributes and content
// newDiv.className = 'new-div';
// newDiv.id = 'newDiv1';
// newDiv.textContent = 'This is a dynamically created div.';

// // Append the new div to the container
// var container = document.getElementById('container');
// container.appendChild(newDiv);

var newDiv = document.createElement("div");

newDiv.className = "new-div";
newDiv.id = "new-div";
newDiv.textContent = "This is dynamcially created Div By Kishan";

var container = document.getElementById("container");
container.appendChild(newDiv);
