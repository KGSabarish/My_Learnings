function removeElement() {
    // Select the div element
    var element = document.getElementById('example');

    // Remove the div element from the DOM
    element.remove();
}