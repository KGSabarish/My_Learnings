function showText() {
    // Get the paragraph element
    var paragraph = document.getElementById('example');

    // Retrieve and log textContent
    console.log('textContent:', paragraph.textContent);

    // Retrieve and log innerText
    console.log('innerText:', paragraph.innerText);
}